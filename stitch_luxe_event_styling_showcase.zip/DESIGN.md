---
name: Ethereal Gala
colors:
  surface: '#faf9f7'
  surface-dim: '#dadad8'
  surface-bright: '#faf9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeec'
  surface-container-high: '#e9e8e6'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1b'
  on-surface-variant: '#49454e'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#7a757e'
  outline-variant: '#cbc4ce'
  surface-tint: '#675782'
  primary: '#675782'
  on-primary: '#ffffff'
  primary-container: '#cbb7e8'
  on-primary-container: '#564670'
  inverse-primary: '#d2beef'
  secondary: '#6a538e'
  on-secondary: '#ffffff'
  secondary-container: '#d6bafd'
  on-secondary-container: '#5e4781'
  tertiary: '#6c5291'
  on-tertiary: '#ffffff'
  tertiary-container: '#d1b3fa'
  on-tertiary-container: '#5b4280'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ecdcff'
  primary-fixed-dim: '#d2beef'
  on-primary-fixed: '#22133a'
  on-primary-fixed-variant: '#4f3f68'
  secondary-fixed: '#ecdcff'
  secondary-fixed-dim: '#d6bafd'
  on-secondary-fixed: '#250d46'
  on-secondary-fixed-variant: '#523b75'
  tertiary-fixed: '#eddcff'
  tertiary-fixed-dim: '#d7baff'
  on-tertiary-fixed: '#260a49'
  on-tertiary-fixed-variant: '#533a78'
  background: '#faf9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e3e2e0'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 96px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 32px
  margin-desktop: 80px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style

This design system is crafted for a premier luxury event styling firm, focusing on an **Editorial Modern Luxury** aesthetic. The brand personality is sophisticated yet whimsical—reminiscent of a high-fashion garden party at dusk. It aims to evoke a sense of "dreamlike exclusivity," where every digital touchpoint feels as meticulously curated as a physical event space.

The visual style leans into **Minimalism with Glassmorphic accents**. By utilizing generous whitespace (Pearl White) and a soft, tonal palette of purples, the interface feels airy and immersive. High-contrast typography provides the "Vogue-style" editorial edge, ensuring the brand feels authoritative in the luxury space while maintaining a soft, approachable elegance.

## Colors

The palette is anchored by **Pearl White**, used as a luminous canvas to allow photography and floral accents to shine. The primary and secondary purples (**Lavender Mist** and **Soft Lilac**) provide a romantic, misty atmosphere, while **Wisteria Purple** acts as a deeper anchor for interactive elements.

**Champagne Gold** is used sparingly as a "Highlight" color—reserved for call-to-action buttons, delicate borders, or premium badges—replicating the shimmer of physical event decor. **Charcoal** provides high-legibility for body text, ensuring the sophisticated typography remains grounded and professional.

## Typography

The typography system relies on a dramatic contrast between the serif and sans-serif families. 

**Bodoni Moda** is the voice of the brand—used for large, impactful headlines. Its high stroke contrast embodies the editorial luxury requirement. For digital immersion, use the `display-lg` size for hero sections to create a magazine-cover feel.

**Hanken Grotesk** provides a clean, modern counterpoint. It is used for all functional text, ensuring that even at small sizes, the information is clear and professional. The `label-caps` style should be used for category tags or small navigation elements to add a touch of structured elegance.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop to maintain a controlled, gallery-like presentation. It uses a 12-column structure with wide gutters (32px) to prevent the UI from feeling cluttered.

Immersion is achieved through "breathable" design. Section gaps are intentionally large (120px) to separate different event showcases, allowing each "dreamlike" visual to stand alone. On mobile, the margins tighten to 20px, and content reflows into a single column, prioritizing full-width imagery that bleeds to the edges to maintain the immersive feel.

## Elevation & Depth

To maintain a "light as air" feel, depth is created through **Glassmorphism** and **Ambient Shadows**.

1.  **Surfaces:** Use semi-transparent backdrops (`#F9F8F6` at 80% opacity) with a 12px backdrop-blur for navigation bars and overlay cards.
2.  **Shadows:** Avoid harsh, black shadows. Use soft, diffused shadows tinted with the primary purple: `rgba(167, 139, 207, 0.12)`.
3.  **Layering:** Elements should appear to float. Imagery should often overlap slightly with text containers or secondary decorative shapes (like soft-edged circles in Lavender Mist) to create a sense of physical arrangement.

## Shapes

The shape language is **Rounded**, reflecting the organic curves found in floral arrangements and balloon arches. 

While the main containers and imagery use a standard `1rem` corner radius, interactive "Pill" shapes are used for buttons and chips to add a softer, more inviting touch. Avoid sharp 90-degree angles to keep the "dreamlike" aesthetic consistent throughout the system.

## Components

### Buttons
- **Primary:** Champagne Gold background with White text. Pill-shaped. Subtle lift on hover with an ambient gold glow.
- **Secondary:** Wisteria Purple outline (1px) with Lavender Mist text. Pill-shaped.

### Cards
- **Event Showcase:** Large-scale imagery with a 1rem radius. Text labels should be overlaid using a glassmorphic footer at the bottom of the image.
- **Service Cards:** Pearl White background with a Soft Lilac top-border (2px) and an ambient shadow.

### Inputs & Fields
- **Style:** Underlined fields with a 1px Soft Lilac border. Labels in `label-caps` positioned above the line. Focus state shifts the border to Champagne Gold.

### Decorative Elements
- **Wisteria Accents:** Use soft-focus, translucent purple circles behind key blocks of text to create depth and visual interest without distracting from the content.
- **Dividers:** Use extremely thin (0.5px) lines in Champagne Gold for separating high-level editorial sections.